-- Joins
-- Filter
-- Sort
-- Group by

use hr;
select * from countries limit 100;
select * from departments limit 10;
select * from locations limit 10;
select * from employees limit 10;

-- join: inner join
-- left join, right join, inner join

select *
from employees a 
join departments b
on a.department_id = b.department_id
join locations c 
on b.location_id = c.location_id;

-- Filter the name of those employees which belong to Executive
select * from employees
where department_id in (select department_id from departments where department_name ="Executive");

-- select
-- from 
-- where
-- group by
-- having
-- order by

-- Where vs Having
-- Where filters the main table/ original table
-- Having: Filters the aggregated table, the output generated from the group by clause

select * from employees
where department_id =90
and manager_id =0
order by salary desc;


